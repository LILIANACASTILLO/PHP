<?php
include_once("model/Model.php");

class Controller{
	public $model;

	public function _contruct()
	{
		$this->model=new Model();

	}

	public function invoke()
	{
		if(!isset($_GET['book']))
		{
			$book= $this->model->getBookList();
			include 'view/booklist.php'
		}
		else
		{
			$book= $this->model->getBook($_GET['book']);
			include 'view/viewbook.php';
		}
	}

}
?>